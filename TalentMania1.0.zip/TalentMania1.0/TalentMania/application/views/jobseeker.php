

<?php 
   if($this->session->flashdata('true'))
   {
 ?>
   <div class="alert alert-success"> 
     <?php  echo $this->session->flashdata('true'); ?>
<?php    
}
?>
<br>

<a href="<?php echo site_url('welcome'); ?>">Build your Profile</a> 
<!-- <?php if($getApproval['approval'] > 0): ?>
<a href="<?php echo site_url('skillendorsed'); ?>">Skill Endorsement</a>
<a href="<?php echo site_url('followcompany'); ?>">Follow Company</a> 
<?php endif; ?>
<?php if($getApproval['hired'] == 1):?>
    <img src="<?php echo base_url(); ?>images/hired.png" alt="Hired">
<?php endif; ?>
<?php if($getApproval['approval'] == 1):?>
    <img src="<?php echo base_url(); ?>images/gold_seal.jpg" alt="gold">
<?php elseif($getApproval['approval'] == 2):?>
    <img src="<?php echo base_url(); ?>images/silver_seal.jpg" alt="silver">
<?php elseif($getApproval['approval'] == 3):?>
    <img src="<?php echo base_url(); ?>images/bronze_seal.jpg" alt="bronze">
<?php endif; ?> -->
