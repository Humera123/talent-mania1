<html>
    <head>
        <title>Talent Mania</title>
       
        <script type = 'text/javascript' src = "<?php echo base_url(); ?>js/bootstrap.min.js"></script>
        <link rel = "stylesheet" type = "text/css" href = "<?php echo base_url(); ?>css/bootstrap.min.css">        

        <link rel = "stylesheet" type = "text/css" href = "<?php echo base_url(); ?>css/custom_style.css">
        <link rel = "stylesheet" type = "text/css" href = "<?php echo base_url(); ?>js/autocomplete/easy-autocomplete.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>    
        <script type = 'text/javascript' src = "<?php echo base_url(); ?>js/autocomplete/jquery.easy-autocomplete.min.js"></script>
        <script type = 'text/javascript' src = "<?php echo base_url(); ?>js/system.js"></script>
    </head>

    <body>
        <div class="container">
        